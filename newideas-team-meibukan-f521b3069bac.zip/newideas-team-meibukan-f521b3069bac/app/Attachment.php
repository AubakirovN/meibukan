<?php

namespace App;

use Corcel\Attachment as Corcel;

class Attachment extends Corcel
{
	protected $connection = 'wordpress';

	public function getTitle()
    {
    	return Toolkit::getCurrentLangText($this->post_title);
    }

    public function getCaption()
    {
    	return Toolkit::getCurrentLangText($this->post_excerpt);
    }
}
