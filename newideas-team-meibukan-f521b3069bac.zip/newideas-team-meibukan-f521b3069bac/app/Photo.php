<?php

namespace App;

use App\Post as Corcel;

class Photo extends Corcel
{
    protected $postType = 'photo';

	  public function getImg(){
		return $this->getMeta('meta_value');
	}


	  public function getMeta($name) {
    	foreach($this->meta as $item) {
    		if($item->meta_key == $name) 
    			return $item->meta_value;
    	}
    }
}
