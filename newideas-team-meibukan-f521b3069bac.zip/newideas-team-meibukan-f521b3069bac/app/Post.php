<?php

namespace App;

use Corcel\Post as Corcel;

class Post extends Corcel
{
    protected $connection = 'wordpress';

    public function getTitle()
    {
    	return Toolkit::getCurrentLangText($this->post_title);
    }

    public function getDescription()
    {
    	return mb_substr(strip_tags(Toolkit::getCurrentLangText($this->getContent())),0,200);
    }

	public function getContent()
    {
    	return str_replace("\r\n\r\n",'<br \><br \>',Toolkit::getCurrentLangText($this->post_content));
    }

    public function haveImage()
    {
      return !is_null($this->meta->_thumbnail_id);
    }

    public function getImage($type=null)
	{
		if(!is_null($this->meta->_thumbnail_id)){
			$image = \App\Attachment::find($this->meta->_thumbnail_id);

			if($type == 'small')
				return \Croppa::url($image->guid, 150, 70);
			elseif($type == 'medium')
				return \Croppa::url($image->guid, 600, 350);
			elseif($type == 'large')
				return \Croppa::url($image->guid, 1200,600);
            elseif ($type == 'video') {
                return \Croppa::url($image->guid, 365, 205);
            }
            elseif ($type == 'photo') {
                return \Croppa::url($image->guid, 260, 185);
            }
            elseif($type == 'mini')
                return \Croppa::url($image->guid, 69,69);
			return $image->guid;
		}
		return "/assets/images/cover-post.jpg";
    }

    
    public function getMenuParentID()
    {
        $meta = \App\PostMeta::where('meta_key', '_menu_item_object_id')->where('meta_value', $this->ID)->first();
        return $meta == null ? -1 : $meta->post_id;
    }

    public function getDate()
    {   
        return date('d',strtotime($this->post_date)).'.'.date('m',strtotime($this->post_date)).'.'.date('Y',strtotime($this->post_date));
    }

    public function getUrl()
    {
        
        return '/'. (\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale() .'/'). array_keys($this->terms['category'])[0] . '/view/' . $this->ID;
    }

}
