<?php

namespace App;

use Corcel\PostMeta as Corcel;

class PostMeta extends Corcel
{
    protected $connectio = 'wordpress';
}
