<?php

namespace App;

use Corcel\TermTaxonomy as Corcel;

class TermTaxonomy extends Corcel
{
    protected $connection = 'wordpress';
}
