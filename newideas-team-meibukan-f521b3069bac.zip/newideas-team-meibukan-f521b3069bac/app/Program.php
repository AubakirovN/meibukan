<?php

namespace App;

use App\Post as Corcel;

class Program extends Corcel
{
    protected $postType = 'program';

    public function getCost() {
        return Toolkit::getCurrentLangText($this->getMeta('wpcf-cost'));
    }
    public function getLength(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-lenght'));
    }
    public function getParticipant() {
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-participant'));
    }
    public function getNumberofPeople(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-number-of-people'));
    }
    public function getAge(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-age'));
    }
    public function getURL(){
        return '/program/view/' . $this->ID;
    }
    public function getMeta($name) {
    	foreach($this->meta as $item) {
    		if($item->meta_key == $name) 
    			return $item->meta_value;
    	}
    }
}
