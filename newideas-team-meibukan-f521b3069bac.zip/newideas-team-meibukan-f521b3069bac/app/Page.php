<?php

namespace App;

use App\Post as Corcel;

class Page extends Corcel
{
	protected $postType = 'page';
	
    

}