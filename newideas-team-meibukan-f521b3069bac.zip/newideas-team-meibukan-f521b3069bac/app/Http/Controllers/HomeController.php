<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Page;
use App\Term;
use App\Post;
use App\Program;
use App\Photo;
use App\Video;
use App\Champion;
use App\Http\Requests;

use App\Attachment;

class HomeController extends Controller
{
	/**
	 * 
	 */
	public function category($sub_category = null)
	{
		$segments_count = count(\Request::segments());
		$slug = \Request::segment($segments_count);
		$category = Term::where('slug', $slug)->first();
		
		if($category == null)
			abort(404);

		$sub_menu = $category->getSubItems();	

		

		if($sub_category != null) {
			$parent_category = Term::where('slug', \Request::segment($segments_count-1))->first(); 

			if($parent_category == null || $parent_category->slug == $sub_category)
				abort(404);

			$sub_menu = $parent_category->getSubItems();
		}

		$posts = Post::taxonomy('category', $slug)->status('publish')->orderby('post_date', 'desc')->paginate(3);
		
		return view('category', compact('posts', 'category', 'sub_menu', 'parent_category'));
	}

    public function page($param = null, $subparam = null )
    {
    
    	$page = Page::where('post_name', $param)->where('post_status', 'publish')->first();
    	
    	if($page == null)
			abort(404);

		$sub_menu = \App\Menu::getSubMenu('main-menu', $page->ID);

		if($sub_menu == null)
			abort(404);

		$flag = true;
		$sub_page = null;
		foreach ($sub_menu as $menu) {
			if($menu->slug == $subparam) {
				$flag = false;
				$sub_page = Page::find($menu->ID);
			}
		}

		if($sub_page == null || ($flag && $subparam != null && $sub_page->post_parent != $page->ID))
			abort(404);

		return view('page', compact('page', 'sub_page', 'sub_menu'));
    }

    public function viewPost($id = null)
    {
    	$post = Post::find($id);

    	$segments_count = count(\Request::segments());
		$slug = \Request::segment($segments_count);
		
		$lang = \LaravelLocalization::getCurrentLocale();
		if($lang == 'en' || $lang== 'ru'){
			$category = Term::where('slug', \Request::segment(2))->first();
			$parent_category = Term::where('slug', \Request::segment(2))->first();
		}
		else{
			$category = Term::where('slug', \Request::segment(1))->first();
			$parent_category = Term::where('slug', \Request::segment(1))->first();
		}
		if($category == null)
			abort(404);

		$sub_menu = $category->getSubItems();

			if($parent_category == null )
				abort(404);

			$sub_menu = $parent_category->getSubItems();
		

    	return view('single', compact('post','category','sub_menu'));
    }

    public function program()
    {
    	$programs = Program::status('publish')->orderby('menu_order', 'desc')->get();
    	
    	return view('program-page', compact('programs'));
    }

    public function viewProgram($id = null){

    	$program = Program::find($id);
    	
		/*$slug = \Request::segment(1);
		$category = Term::where('slug', $slug)->first();*/
		
		$lang = \LaravelLocalization::getCurrentLocale();
		if($lang == 'en' || $lang== 'ru'){
			$category = Term::where('slug', \Request::segment(2))->first();
			$parent_category = Term::where('slug', \Request::segment(2))->first();
		}
		else{
			$category = Term::where('slug', \Request::segment(1))->first();
			$parent_category = Term::where('slug', \Request::segment(1))->first();
		}
		
		if($category == null)
			abort(404);
  
    	$sub_menu  = Program::status('publish')->orderby('menu_order', 'asc')->get();
    	
    	
    	return view('single-program', compact('program','category','sub_menu'));
    }

    public function champions(){

    	$champions = Champion::status('publish')->orderby('menu_order', 'asc')->get();
   
    	return view('champions-page', compact('champions'));
    }

    public function allMedia($sub_category = null)
    {
    	$segments_count = count(\Request::segments());
		$slug = \Request::segment($segments_count);
		$category = Term::where('slug', $slug)->first();
	    
		if($category == null)
			abort(404);

		if($sub_category != null) {
			$parent_category = Term::where('slug', \Request::segment($segments_count-1))->first(); 

			if($parent_category == null || $parent_category->slug == $sub_category)
				abort(404);

			$sub_menu = $parent_category->getSubItems();
		}

    	$gallery = Photo::status('publish')->orderby('post_date', 'desc')->paginate(6);
    	$videos = Video::status('publish')->orderby('post_date', 'desc')->paginate(6);
    	
    	return view('media', compact('gallery','videos', 'sub_menu', 'category'));
    }

    public function viewGallery($id = null){
    	
    	$images = array();
    	$gallery = Photo::find($id);

    	$id = $gallery->getContent();
   		$output = preg_match_all('/\[gallery.+ids=[\'"](.+?)[\'"]\]/', $id, $matches);
		$extracted = explode(',', $matches[1][0]);

    	foreach ($extracted as $key => $img) {
    		$images[] = \App\Attachment::find($img);
    		
    	}
     	$segments_count = count(\Request::segments());
		$slug = \Request::segment($segments_count);
		
		$lang = \LaravelLocalization::getCurrentLocale();
		if($lang == 'en' || $lang== 'ru'){
			$category = Term::where('slug', \Request::segment(2))->first();
			$parent_category = Term::where('slug', \Request::segment(2))->first();
		}
		else{
			$category = Term::where('slug', \Request::segment(1))->first();
			$parent_category = Term::where('slug', \Request::segment(1))->first();
		}
		if($category == null)
			abort(404);
		
		$sub_menu = $category->getSubItems();
		
		if($parent_category == null )
			abort(404);

		$sub_menu = $parent_category->getSubItems();

    	return view('gallery', compact('gallery','images','category','sub_menu' ));
    }

    public function viewVideo($id = null){
    	$video = Video::find($id);
    	$segments_count = count(\Request::segments());
		$slug = \Request::segment($segments_count);
		
		$lang = \LaravelLocalization::getCurrentLocale();
		if($lang == 'en' || $lang== 'ru'){
			$category = Term::where('slug', \Request::segment(2))->first();
			$parent_category = Term::where('slug', \Request::segment(2))->first();
		}
		else{
			$category = Term::where('slug', \Request::segment(1))->first();
			$parent_category = Term::where('slug', \Request::segment(1))->first();
		}
		if($category == null)
			abort(404);
		
		$sub_menu = $category->getSubItems();
			if($parent_category == null )
				abort(404);

		$sub_menu = $parent_category->getSubItems();

    	return view('single-video',compact('video','category','sub_menu'));
    }

}
