<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::post('/ajax/mail', function() {

	Mail::send('emails.order', $_POST, function ($m) {
            $m->to('bakdauren@newideas.kz')->subject('Заявка!');
    });

});

Route::group(
	[
		'prefix' => LaravelLocalization::setLocale(),
		'middleware' => [ 'localeSessionRedirect', 'localizationRedirect' ]
	],
function()
    {
        /** ADD ALL LOCALIZED ROUTES INSIDE THIS GROUP **/
       Route::get('/', function () {

			$program = App\Program::status('publish')->orderby('menu_order', 'asc')->skip(2)->take(3)->get();
			$champions = App\Champion::status('publish')->orderby('menu_order', 'asc')->take(6)->get();
			$videos = App\Video::status('publish')->orderby('post_date', 'desc')->take(3)->get();
			$about = App\Page::slug('about-us')->first();

		    return view('welcome', compact('program','champions', 'videos','about'));
		});

        Route::get('/search', function() {
			return view('search');
		});
		
        Route::get('/program', 'HomeController@program');
        Route::get('/program/view/{id}', 'HomeController@viewProgram');
        Route::get('/champion', 'HomeController@champions');
		Route::get('/press/{sub_category?}', 'HomeController@category');

		
		
		Route::get('/press/view/{id}', 'HomeController@viewPost');
		Route::get('/all-media/{sub_category?}', 'HomeController@allMedia');
		Route::get('/photo/view/{id}', 'HomeController@viewGallery');
		Route::get('/video/view/{id}', 'HomeController@viewVideo');

        Route::get('/{param}/{subparam?}', 'HomeController@page');
			


    });



