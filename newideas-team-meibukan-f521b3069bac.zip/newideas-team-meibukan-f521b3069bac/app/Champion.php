<?php

namespace App;

use App\Post as Corcel;

class Champion extends Corcel
{
    protected $postType = 'champion';

    public function getBirth(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-birth'));
    }
    public function getHeight(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-height'));
    }
    public function getLevel(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-level'));
    }
    public function getStatus(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-status'));
    }
    public function getWeight(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-weight'));
    }
    public function getWins(){
    	return Toolkit::getCurrentLangText($this->getMeta('wpcf-wins'));
    }
    public function getMeta($name) {
    	foreach($this->meta as $item) {
    		if($item->meta_key == $name) 
    			return $item->meta_value;
    	}
    }
}
