@extends('master')

@section('title', trans('options.notfound'))

@section('content')
<section id="main">
	<div class="container notfound">
		<div class="row">
			<div class="col-md-12 text-center">
				<p style="font-size:60px">404</p>
				<h1>{{trans('options.notfound')}}.</h1>
			</div>
		</div>
	</div>
</section>

@stop
