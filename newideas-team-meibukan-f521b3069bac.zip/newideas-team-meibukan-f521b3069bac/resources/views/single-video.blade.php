@extends('master')
@section('title',$video->getTitle())
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
							
				<div class="col-md-12 col-xs-12 single">
					<h3 class="news-title center-block">{{$video->getTitle()}}</h3>
					<span class="date">{{$video->getDate()}}</span>
					<article>
						<div class="embed-responsive embed-responsive-16by9">
							<iframe width="100%" height="315" src="https://youtube.com/embed/{{$video->getID()}}?modestbranding=1&autohide=1&showinfo=0" frameborder="0" allowfullscreen>
							</iframe>
						</div>
						{{$video->getContent()}}
					</article>
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection