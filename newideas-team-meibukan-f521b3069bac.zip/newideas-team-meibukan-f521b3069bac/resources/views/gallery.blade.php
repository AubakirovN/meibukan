@extends('master')
@section('title', $gallery->getTitle())
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
								
				<div class="col-md-12 col-xs-12 media">
					<h3 class="page-title center-block">{{$gallery->getTitle()}}</h3>
					@foreach($images as $img)
						
							<div class="col-md-3 col-xs-6">
							<a href="{{$img->guid}}" data-lightbox="gallery" data-title="{{$img->getTitle()}}">
								<img src="{{$img->guid}}" class="img-responsive">
							</a>
						 
						</div>
						
					
					@endforeach
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection