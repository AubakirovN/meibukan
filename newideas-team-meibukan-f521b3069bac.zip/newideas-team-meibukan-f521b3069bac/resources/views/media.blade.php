@extends('master')

@if($category->slug == 'photo')
	@section('title', trans('options.photo'))
@elseif($category->slug == 'video')
	@section('title', trans('options.video'))
@endif

@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3 col-xs-12 navmenu single-news revealOnScroll" data-animation="fadeInLeft">
					<ul>
						@foreach($sub_menu as $menu)
						<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{'all-media/'.$menu->slug}}" @if($category->slug == $menu->slug) class="current" @endif>{{$menu->getTitle()}}</a></li>
						@endforeach
					</ul>
				</div>
				
				<div class="col-md-9 col-xs-12 media">
					@if($category->slug == 'photo')
						@foreach($gallery as $photo)
							<div class="col-md-4 col-xs-12">
								<img src="{{$photo->getImage('photo')}}" class="img-responsive">
								<span class="date">{{$photo->getDate()}}</span>
								<span class="video-link"><a href="/photo/view/{{$photo->ID}}" class="link">{{$photo->getTitle()}}</a></span>
							</div>
						@endforeach
					@elseif($category->slug == 'video')
						@foreach ($videos as $video)
						<div class="col-md-6 col-xs-12 video-block">
							<a href="/video/view/{{$video->ID}}">
								<img src="{{$video->getImage('video')}}" class="img-responsive">
							</a>
							<span class="date">{{$video->getDate()}}</span>
							<span class="video-link"><a href="/video/view/{{$video->ID}}" class="link">{{$video->getTitle()}}</a></span>
						</div>
						@endforeach
					@endif
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection