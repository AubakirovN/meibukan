@if (isset($_POST['name']))
	<?php 
		$name = $_POST['name'];
		echo 'Имя/Ат/Name: ' . $name . ' <br>';
	?>
@endif
<br>
@if (isset($_POST['phone']))
	<?php 
		$phone = $_POST['phone'];
		echo 'Телефон/Telephone: ' . $phone . ' <br>';
	?>
@endif
<br>
@if (isset($_POST['email']))
	<?php 
		$email = $_POST['email'];
		echo 'Email: ' . $email . ' <br>';
	?>
@endif
<br>
@if (isset($_POST['msg']))
	<?php 
		$msg = $_POST['msg'];
		echo 'Сообщение/Message: ' . $msg . ' <br>';
	?>
@endif