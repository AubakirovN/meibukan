@extends('master')
@section('title',trans('options.website'))

@section('content')
    <section id="slider" class="hidden-xs">
        <div class="container">
            <div class="row">
                @include('widgets.slider')
            </div> 
        </div>
        <a id="down" class="page-scroll" href="#main"></a>
    </section>
    <section id="main">
        <div class="container">
             <div class="row hidden-xs revealOnScroll" data-animation="fadeInUp" data-timeout="200">
                <h1 class="section-title">{{trans('options.feature')}}</h1>
                <div class="col-md-4 col-xs-12">
                    <div class="feature">
                        <span class="icon"></span>
                        <span>{{trans('options.daily')}}</span>
                    </div>
                    <div class="feature">
                        <span class="icon icon-2"></span>
                        <span>{{trans('options.hit')}}</span>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                    <div class="feature feature-middle">
                        <span class="icon icon-3"></span>
                        <span>{{trans('options.age-limit')}}</span>
                        <p>
                            {{trans('options.age-limit-text')}}
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                    <div class="feature">
                        <span class="icon icon-4"></span>
                        <span>{{trans('options.gender-limit')}}</span>
                    </div>
                    <div class="feature">
                        <span class="icon icon-5"></span>
                        <span>{{trans('options.intellect')}}</span>
                    </div>
                </div>
            </div>
            <div class="row program" id="programms">
                <h1 class="section-title">{{trans('options.program')}}</h1>
                @foreach($program as $key => $pro)
                <div class="col-md-4 col-xs-12 revealOnScroll" data-animation="fadeInRight">
                    <div class="type">
                        <img src="{{$pro->getImage()}}" class="img-responsive">
                        <div class="desc">
                            <span class="name">{{ $pro->getTitle()}}</span>
                            <ul>
                                <li>{{trans('options.cost')}}: {{$pro->getCost()}}</li>
                                <li>{{trans('options.lenght')}}: {{$pro->getLength()}}</li>
                                <li>{{trans('options.participant')}}: {{$pro->getParticipant()}}</li>
                                <li>{{trans('options.people')}}: {{$pro->getNumberofPeople()}}</li>
                                <li>{{trans('options.age')}}: {{$pro->getAge()}}</li>
                            </ul>
                            
                            <a href="{{$pro->getUrl()}}" class="btn btn-default enroll">{{trans('options.enroll')}}</a>
                            
                        </div>
                    </div>  
                </div>
                @endforeach
               
                <div class="col-md-12 col-xs-12">
                    <div class="center-block">
                        <a href="/program" class="all-program revealOnScroll" data-animation="fadeInRight">{{trans('options.all-program')}}</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="free-lesson">
        @include('widgets.free')
    </section>
    <section id="champions">
        <div class="container">
            <div class="row">
                @include('widgets.champions')
            </div>
        </div>
    </section>
    <section id="trainer">
        <div class="container">
            <div class="row">
                <h2 class="section-title">{{trans('options.trainer')}}</h2>
                <div class="col-md-6 trainer revealOnScroll" data-animation="slideInLeft" data-timeout="250">
                    <img src="/assets/images/trainer.png" class="img-responsive">
                </div>
                <div class="col-md-6 about revealOnScroll" data-animation="slideInRight" data-timeout="250">
                    <h3>{{trans('options.welcome')}}</h3>
                    <p>
                    @if(isset($about))
                        {!!$about->getContent()!!}
                    @else
                    «Meibukan» - ҚР Годзю-рю Карате-до Федерациясына қарасты жекпе-жек өнері клубы (бұдан әрі – «Клуб»). Клуб қатысушылары негізінен Каратенің Годзю-рю бағыты бойынша жаттығады.
                     <br>Годзю-рю – адамның ішкі энергетикасын пайдаланатын, каратенің дәстүрлі, жауынгерлік қалпын өзгеріссіз сақтап қалған жекпе-жек түрі. Ол тек спорттық шынығуға ғана емес, қоян-қолтық ұрыс жүргізуге, қорғануға бағытталған.
                    </p>
                    @endif
                    <span class="name">{{trans('options.trainer-name')}}</span>
                    <span class="status">{{trans('options.main-trainer')}}</span>
                    <span class="more"><a href="/about-us/club" class="">{{trans('options.more')}} <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a></span>
                </div>
            </div>
        </div>
    </section>
    <section id="history">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xs-12 revealOnScroll" data-animation="fadeInUp">
                    <div class="title">
                        <span>{{trans('options.philosophy')}}</span>
                        <H2>{{trans('options.martial-arts')}}</H2>
                    </div>
                    <div class="text">
                        <p>{{trans('options.history-text')}}</p>
                    </div>
                    <a href="/goju-ryu/history"><button class="btn btn-default more">{{trans('options.more')}}</button></a>
                </div>
                <div class="col-md-4 visible-md visible-lg">
                </div>
            </div>
        </div>
    </section>
    <section id="feedback">
        <div class="container">
            <div class="row">
                <h2 class="section-title">{{trans('options.feedback')}}</h2>
                @include('widgets.feedbacks')
            </div>
        </div>
    </section>
    <section id="free-lesson">
        @include('widgets.free')
    </section>
    <section id="media">
        <div class="container">
            <div class="row">
                <h2 class="section-title">{{trans('options.media')}}</h2>
                <div class="col-md-12 col-xs-12 main-video">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/UfNX9y2eaGE" frameborder="0" allowfullscreen></iframe>
                    </div>
                </div>
                @foreach($videos as $video)
                <div class="col-md-4 col-xs-12 col-sm-4">
                    <div class="media-item">
                        @if($video->haveImage())
                        <img src="{{$video->getImage('video')}}" class="img-responsive">
                        @else
                        <img src="/assets/images/media1.jpg" class="img-responsive">    
                        @endif
                        <div class="caption">
                            <span class="date">{{$video->getDate()}}</span>
                            <span class="title">
                                <a href="/video/view/{{$video->ID}}">{{$video->getTitle()}}</a>
                            </span>
                            <span class="button"></span>
                        </div>
                    </div>
                    
                </div>
                @endforeach
            </div>
        </div>
    </section>
    <section id="where">
        @include('widgets.map')
    </section>
@endsection
