@extends('master')
@section('content')
	<section id="main">
		<div class="container about-us contact">
			<div class="row">
				
			@include('widgets.menu')
				
			@if(isset($sub_page))
				@section('title', $sub_page->getTitle())
				
				@if($sub_page->slug == 'frequently-asked-questions')
				<div class="col-md-9">
					<div class="panel-group" id="accordion">
						<div class="title">
							<h3>Жиі қойылатын сұрақтар</h3>
						</div>
					  <div class="panel panel-default">
					    <div class="panel-heading">
					    <i class="fa fa-caret-right" aria-hidden="true"></i>
					      <h4 class="panel-title">
					        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
					        Collapsible Group 1</a>
					      </h4>
					    </div>
					    <div id="collapse1" class="panel-collapse collapse">
					      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
					      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
					      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
					      commodo consequat.</div>
					    </div>
					  </div>
					  <div class="panel panel-default">
					    <div class="panel-heading">
					    <i class="fa fa-caret-right" aria-hidden="true"></i>
					      <h4 class="panel-title">
					        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
					        Collapsible Group 2</a>
					      </h4>
					    </div>
					    <div id="collapse2" class="panel-collapse collapse">
					      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
					      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
					      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
					      commodo consequat.</div>
					    </div>
					  </div>
					  <div class="panel panel-default">
					    <div class="panel-heading">
					    <i class="fa fa-caret-right" aria-hidden="true"></i>
					      <h4 class="panel-title">
					        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
					        Collapsible Group 3</a>
					      </h4>
					    </div>
					    <div id="collapse3" class="panel-collapse collapse">
					      <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
					      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
					      minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
					      commodo consequat.</div>
					    </div>
					  </div>
					</div>
				</div>
				@elseif($sub_page->slug == 'contact')
				<div class="col-md-9">
					<h3 class="page-title center-block">{{$sub_page->getTitle()}}</h3>
                    <div class="row contact-inf center-block">
                        <div class="col-md-4 col-xs-12 address">
                            <span class="title">{{trans('options.address')}}</span>
                            <span class="detail">{!!trans('options.header-address')!!}</span>
                        </div>
                        <div class="col-md-4 col-xs-12 email">
                            <span class="title">E-mail</span>
                            <span class="detail"><a href="mailto:meibukan.mac@gmail.com">meibukan.mac@gmail.com</a></span>
                        </div>
                        <div class="col-md-4 col-xs-12 phone">
                            <span class="title">{{trans('options.phone')}}</span>
                            <span class="detail">
								<a href="tel:+77279836731">+ 7 (727) 983 67 31</a><br>
								<a href="tel:+77076161414">+7 (707) 616 14 14</a>
							</span>
                        </div>
                    </div>
					<br>
					<span class="sub-title center-block">{!!$sub_page->getContent() !!}</span>
                </div>
                
                @elseif($sub_page->slug == 'feature')
                <div class="col-md-9 col-xs-12 features"> 
					<h3 class="page-title center-block">{{$sub_page->getTitle()}}</h3>
					<span class="sub-title">Годзю-рю каратенің жекпе-жек өнерінің өзге спорттық түрлеріне (киокушин, шито-рю, шотакан карате, таэквон-до, дзю-до, айкидо, бокс, кикбокс, күрес, ММА, т.б.) қарағанда артықшылықтары өте көп. Мысалы, мынадай:</span>
					<div class="col-md-6 col-xs-12 feature">
	                    <span class="icon"></span>
	                    <span class="feature-title">Күнделікті тұрмыста қолданбалы</span>
	                    <p>Таэквондошы сияқты әдемі аяқ көтермеуі мүмкін, бірақ, шабуылдаушыны қарапайым әдістермен ешқандай қиындықсыз тоқтатуды біледі. Палуандар құсап, қарсыласын жерге аунап жатып жеңуді мақұл көрмейді.</p>
					</div>
					<div class="col-md-6 col-xs-12 feature">
						<span class="icon icon-3"></span>
	                    <span>Жас талғамайды</span>
	                    <p>
	                        Яғни, кез-келген жастағы тұлға жаңадан бастап айналыса алады. Мұның қолданбалылығы сонда. Бірінші орынға спорттық мансап қууды емес, адам денсаулығын жақсартуды қойғандықтан, мұнымен кез-келген адам айналыса алады.
	                    </p>
					</div>
					<div class="col-md-6 col-xs-12 feature">
						<span class="icon icon-4"></span>
	                    <span>Жыныс талғамайды</span>
	                    <p>
	                        Қыз-келіншектерге арналған, артық салмақпен күресу, өзін-өзі қорғауды үйрететін арнайы бағдарлама бар.
	                    </p>
					</div>
					<div class="col-md-6 col-xs-12 feature">
                        <span class="icon icon-2"></span>
                        <span>Дұрыс соққы жасауды</span>
                        <p>сонымен қатар оқыстан соққы жасалғанда да аз жарақатпен дұрыс соққы қабылдай алуға үйретеді.</p>
                    </div>
                    <div class="col-md-6 col-xs-12 feature">
                        <span class="icon icon-5"></span>
                        <span>Әмбебап</span>
                        <p>Оған дәлел, дәстүрлі каратемен бірнеше жылдан бері тұрақты айналысып келе жатқан біздің спортшылар тек каратеден ғана емес, самбо, әскери самбо, қолма-қол жекпе-жек, әмбебап жекпе-жек (Unifihgt), кикбоксинг, джиу-джитсу, грэплинг, т.б. жекпе-жек түрлерінен қалалық, республикалық, халықаралық жарыстарда топ жарып жүр.</p>
                    </div>
                    <div class="col-md-6 col-xs-12 feature">
                        <span class="icon icon-6"></span>
                        <span>Интелектуалдық қабілетті арттырады</span>
                        <p>Дәстүрлі карате – жоғарыда айтқанымдай, жабай
						төбелеске немесе құрғақ жетістіктерге негізделмеген. Мұнда – негізгі көңіл кихон (соққы
						мен қорғаныс техникасы) мен рензокуға (жоспарлы ұрыс тәсілдері) ката (әдіс-тәсілдер жиынтығы) мен оның бункайына (тәпсірлері) бөлінеді. Осылардың мың-миллион комбинациясын жаттау барысында баланың жаттау қабілеті артады.</p>
                    </div>
				</div>
				@else
				<div class="col-md-9 col-xs-12">
					<h3 class="page-title center-block">{{$sub_page->getTitle()}}</h3>
					@if($sub_page->haveImage())
					<img src="{{$sub_page->getImage()}}" class="img-responsive about-photo">
					@endif
					<article>
						{!!$sub_page->getContent()!!}
					</article>	
				</div>
                @endif
			@endif
				
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection
