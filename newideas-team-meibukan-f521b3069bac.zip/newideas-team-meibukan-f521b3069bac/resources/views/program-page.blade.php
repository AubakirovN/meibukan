
@extends('master')
@section('title', 'Programs')
@section('content')
	<section id="main">
        <div class="container">
            @include('widgets.program')
        </div>
    </section>
    <section id="free-lesson">
        @include('widgets.free')
    </section>
    <section id="where">
        @include('widgets.map')
    </section>
@endsection