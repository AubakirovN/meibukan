@extends('master')
@section('title', 'Our champions')
@section('content')
	<section id="champions">
        <div class="container">
            <div class="row">
                @include('widgets.champions')
            </div>
        </div>
    </section>
    <section id="free-lesson">
        @include('widgets.free')
    </section>
    <section id="where">
        @include('widgets.map')
    </section>
@endsection