@extends('master')
@section('title',$post->getTitle())
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
				
				@include('widgets.menu')
				
				<div class="col-md-9 col-xs-12 single">
					<a href="{{ URL::previous() }}" class="breadcrumbs"> < {{trans('options.back')}}</a>
					<h3 class="news-title center-block">{{$post->getTitle()}}</h3>
					<span class="date">{{$post->getDate()}}</span>
					@if($post->haveImage())
					<img src="{{$post->getImage()}}" class="img-responsive news-photo" alt="">
					@endif
					<article>
						{!! $post->getContent()!!}
					</article>
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection