@extends('master')
@section('title', 'History')
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3 col-xs-12 navmenu">
				@include('widgets.menu')
				</div>
				<div class="col-md-9 col-xs-12">
					<h3 class="page-title center-block">{{ $page->getTitle()}}</h3>
					<article>
						{!! $page->getContent() !!}
					</article>
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection
