@extends('master')

@section('title', trans('options.search') . (isset($_GET['q']) ? ': ' . $_GET['q'] : ''))

@section('content')
<section id="main">
	<div class="container search">
		<div class="row">
			<script>
			  (function() {
				var cx = '010232328833402542677:gja8nrwilja';
				var gcse = document.createElement('script');
				gcse.type = 'text/javascript';
				gcse.async = true;
				gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
				var s = document.getElementsByTagName('script')[0];
				s.parentNode.insertBefore(gcse, s);
			  })();
			</script>
			<gcse:search></gcse:search>
		</div>
	</div>
</section>
<section id="free-lesson">
    @include('widgets.free')
</section>
<section id="where">
	@include('widgets.map')
</section>
@stop
