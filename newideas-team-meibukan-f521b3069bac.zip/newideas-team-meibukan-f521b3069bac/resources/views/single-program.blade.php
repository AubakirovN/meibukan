@extends('master')
@section('title',$program->getTitle())
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
				
				<div class="col-md-3 col-sm-3 col-xs-12 navmenu revealOnScroll" data-animation="fadeInLeft">
					<ul>
						@foreach($sub_menu as $menu)
						<li>
							<a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{'program/view/'.$menu->ID}}" @if($category->slug == $menu->slug) class="current" @endif>{{$menu->getTitle()}}
							</a>
						</li>
						@endforeach
					</ul>
				</div>
				
				<div class="col-md-9 col-xs-12 single">
					<a href="/program" class="breadcrumbs"> < {{trans("options.back-btn")}}</a>
					<h3 class="news-title center-block">{{$program->getTitle()}}</h3>
					<span class="date">{{$program->getDate()}}</span>
					@if($program->haveImage())
					<img src="{{$program->getImage()}}" class="img-responsive news-photo" alt="">
					@endif
					<article>
						{!! $program->getContent()!!}
						<div class="program-desc">
                            <span class="name">{{ $program->getTitle()}}</span>
                            <ul>
                                <li>{{trans('options.cost') }}: {{$program->getCost()}}</li>
                                <li>{{trans('options.lenght') }}: {{$program->getLength()}}</li>
                                <li>{{trans('options.participant')}}: {{$program->getParticipant()}}</li>
                                <li>{{trans('options.people')}}: {{$program->getNumberofPeople()}}</li>
                                <li>{{trans('options.age')}}: {{$program->getAge()}}</li>
                            </ul>
                            <form method="POST" id="form-for-record">
                                {{csrf_field()}}
                                <div class="form-group">
                                    <input type="tel" name="telephone-number" placeholder="+7 (___) ___ ____" class="form-control tel-input">
                                    <button type="submit" class="btn btn-default enroll">{{trans('options.enroll')}}</button>
                                </div>

                            </form>
                            <!-- <button class="btn btn-default enroll">Жазылу</button> -->
                        </div>
					</article>
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection