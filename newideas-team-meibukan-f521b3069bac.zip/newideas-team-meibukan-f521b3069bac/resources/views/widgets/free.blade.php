<div class="container" id="lesson">
	<div class="row">
		<span class="center-block revealOnScroll" data-animation="bounce" data-timeout="400">{!! trans('options.free-lesson') !!}</span>
		<div class="col-md-4 col-xs-12">
			<input type="text" class="form-group name-input" placeholder="{{trans('options.name-input')}}">
		</div>
		<div class="col-md-4 col-xs-12">
			<input type="text" class="form-group phone-input" placeholder="{{trans('options.phone-input')}}">
		</div>
		<div class="col-md-4 col-xs-12">
			<button class="btn btn-default send">{{trans('options.send')}}<i class="fa fa-paper-plane" aria-hidden="true"></i></button>
		</div>
	</div>
</div>