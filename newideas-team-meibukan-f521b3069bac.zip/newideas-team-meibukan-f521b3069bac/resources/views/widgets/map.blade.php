<div id="map"></div>
<div class="container">
	<div class="contact-form">
	    <input type="text" name="name" class="form-control name-input" placeholder="{{trans('options.name-input')}}">
	    <input type="text" name="email" class="form-control email-input" placeholder="Email">
	    <textarea class="form-control msg-input" rows="5" name="message"></textarea>
	    <button class="btn btn-primary contact">{{trans('options.send')}}<i class="fa fa-paper-plane" aria-hidden="true"></i></button>
	</div>
</div>