<div class="col-md-12 feedbacks revealOnScroll" data-animation="fadeIn" data-timeout="400">
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-1.png" class="img-resposive center-block">
		<span class="person">Арман</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-2.png" class="img-resposive center-block">
		<span class="person">Дархан</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-3.png" class="img-resposive center-block">
		<span class="person">Назерке</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-1.png" class="img-resposive center-block">
		<span class="person">Арман</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-2.png" class="img-resposive center-block">
		<span class="person">Дархан</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-3.png" class="img-resposive center-block">
		<span class="person">Назерке</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-1.png" class="img-resposive center-block">
		<span class="person">Арман</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-2.png" class="img-resposive center-block">
		<span class="person">Дархан</span>
	</div>
	<div>
		<div class="text">
			"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
		</div>
		<img src="/assets/images/person-3.png" class="img-resposive center-block">
		<span class="person">Назерке</span>
	</div>
</div>