    
    <div class="row program">
            <h1 class="section-title">Бағдарламалар</h1>
            @if(isset($programs))
            <?php $count=0;?>
                @foreach( $programs as $program)
                @if($count++ < 3)
                <div class="col-md-4 col-xs-12">
                    <div class="type">
                        <a href="{{$program->getUrl()}}">
                            <img src="{{$program->getImage()}}" class="img-responsive">
                        </a>
                        <div class="desc inner-desc">
                            <span class="name"><a href="{{$program->getUrl()}}">{{$program->getTitle()}}</a></span>
                        </div>
                    </div>  
                </div>
                @else
                <div class="col-md-6 col-xs-12">
                    <div class="type">
                        <a href="{{$program->getUrl()}}">
                            <img src="{{$program->getImage()}}" class="img-responsive">
                        </a>
                        <div class="desc inner-desc">
                            <span class="name"><a href="{{$program->getUrl()}}">{{$program->getTitle()}}</a></span>
                        </div>
                    </div>  
                </div>
                @endif
                @endforeach
            @endif
               
    </div>
    

    