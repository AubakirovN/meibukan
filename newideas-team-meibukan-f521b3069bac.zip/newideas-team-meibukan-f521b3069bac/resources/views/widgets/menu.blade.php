@if(isset($page))

<div class="col-md-3 col-sm-3 col-xs-12 navmenu revealOnScroll" data-animation="fadeInLeft">
<ul>
	@foreach($sub_menu as $menu)
	@if(isset($category))
	<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' :
	\LaravelLocalization::getCurrentLocale().'/'}}{{$page->slug.'/'.$menu->slug}}" @if($category->slug == $menu->slug)
	class="current" @endif>{{$menu->getTitle()}}</a></li>
	@else
	<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' :
	\LaravelLocalization::getCurrentLocale().'/'}}{{$page->slug.'/'.$menu->slug}}" @if($sub_page->slug == $menu->slug)
	class="current" @endif>{{$menu->getTitle()}}</a></li>
	@endif
	@endforeach
</ul>
</div>

@else
	
	<div class="col-md-3 col-sm-3 col-xs-12 navmenu single-news revealOnScroll" data-animation="fadeInLeft">
	@if(isset($parent_category))
	<ul>
		@foreach($sub_menu as $menu)
		<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{$parent_category->slug.'/'.$menu->slug}}" @if($category->slug == $menu->slug) class="current" @endif>{{$menu->getTitle()}}</a></li>
		@endforeach
	</ul>
	@include('widgets.news-widget')
	@else
	<ul>
		@foreach($sub_menu as $menu)
		<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{$category->slug.'/'.$menu->slug}}" @if($category->slug == $menu->slug) class="current" @endif>{{$menu->getTitle()}}</a></li>
		@endforeach
	</ul>
	@endif
	
	</div>

@endif
