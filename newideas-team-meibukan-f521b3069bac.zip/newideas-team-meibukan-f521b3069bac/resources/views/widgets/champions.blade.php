
<h1 class="section-title">{{trans('options.champions')}}</h1>
    @foreach($champions as $key => $champion)
                <div class="col-md-4 champion revealOnScroll" data-animation="flipInX">
                    
                    <img src="{{$champion->getImage()}}" class="img-responsive">
                    
                    <div class="overlay">
                        <div class="border">
                            <span>{{$champion->getTitle()}}</span>
                            <ul>
                                <li>{{trans('options.birth')}}: {{ $champion->getBirth() }}</li>
                                <li>{{trans('options.weight')}}: {{ $champion->getWeight() }}</li>
                                <li>{{trans('options.height')}}: {{ $champion->getHeight() }}</li>
                                <li> {{trans('options.status')}}: {{ $champion->getStatus() }}</li>
                                <li>{{trans('options.level')}}: {{ $champion->getLevel() }}</li>
                                <li>{{trans('options.wins')}}: {{ $champion->getWins() }}</li>
                            </ul> 
                       </div>
                    </div>
                </div>
    @endforeach
         