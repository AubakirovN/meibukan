<div class="col-md-12 main-slider">
  <div class="revealOnScroll" data-animation="fadeInUp">
  	<img src="/assets/images/slider/1.png" class="img-responsive">
  	<div class="slider-text">
  		<span class="date">13.06.2016</span>
  		<span class="text">{{trans('options.slider-text')}}</span>
  	</div>
  	<div class="button">
  		<button class="btn btn-default more">{{trans('options.more')}}</button>
  	</div>
  </div>
  <div>
    <img src="/assets/images/slider/1.png" class="img-responsive">
    <div class="slider-text">
      <span class="date">13.06.2016</span>
      <span class="text">{{trans('options.slider-text')}}</span>
    </div>
    <div class="button">
      <button class="btn btn-default more">{{trans('options.more')}}</button>
    </div>
  </div>
  <div>
    <img src="/assets/images/slider/1.png" class="img-responsive">
    <div class="slider-text">
      <span class="date">13.06.2016</span>
      <span class="text">{{trans('options.slider-text')}}</span>
    </div>
    <div class="button">
      <button class="btn btn-default more">{{trans('options.more')}}</button>
    </div>
  </div>
</div>