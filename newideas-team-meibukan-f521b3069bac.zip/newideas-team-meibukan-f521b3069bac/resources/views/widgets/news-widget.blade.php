<?php 
	
	$posts = \App\Post::taxonomy('category', 'press')->status('publish')->orderby('post_date', 'asc')->take(3)->get();

?>
<div class="related-news">
	<h4>{{trans('options.widget-title')}}</h4>
	<div class="widget-container">
		<ul>
			@if( isset($posts))
			@foreach ($posts as $post)
			<li>
				<a href="{{$post->getUrl()}}"><img src="{{$post->getImage('mini')}}" class="article-img"></a>
				<div class="item-details">
					<span class="date">{{$post->getDate()}}</span>
					<a href="{{ $post->getUrl() }}">{{$post->getTitle()}}</a>
				</div>
			</li>
			@endforeach
			@endif
		
		</ul>
	</div>
</div>


