@extends('master')
@section('title','News')
@section('content')
	<section id="main">
		<div class="container">
			<div class="row">
				
				@include('widgets.menu')
				
				<div class="col-md-9 col-xs-12 single">
					<h3 class="page-title center-block">{{$category->getTitle()}}</h3>
					@foreach($posts as $post)
					<div class="news-item">
						<h4 class="news-title"><a href="{{$post->getUrl()}}">{{$post->getTitle()}}</a></h4>
						<span class="date">{{$post->getDate()}}</span>
						@if($post->haveImage())
						<img src="{{$post->getImage('large')}}" class="img-responsive news-photo">
						@endif
						<article>
							{{$post->getDescription()}}
						</article>
						<a href="{{$post->getUrl()}}"><button class="btn btn-default more">Толық оқу</button></a>
					</div>
					@endforeach
					{!! $posts->render() !!}
				</div>
			</div>
		</div>
	</section>
	<section id="free-lesson">
        @include('widgets.free')
    </section>
	<section id="where">
		@include('widgets.map')
	</section>
@endsection