<?php 

	if(Request::segment(1) == null || ((Request::segment(1) == 'kk' || Request::segment(1) == 'ru' || Request::segment(1) == 'en') && Request::segment(2) == null))
		$path = "";
	elseif(Request::segment(1) == 'ru' || Request::segment(1) == 'en')
		$path = str_replace(array('en/', 'ru/'), '',  Request::path());
	else
		$path = Request::path();

	$menu = \App\Menu::getMenu('main-menu');

?>
<!DOCTYPE html>
<html lang="{{\LaravelLocalization::getCurrentLocale()}}" data-framework="backbonejs">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=.99">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="">

    <title>@yield('title')</title>

	<link rel="icon" sizes="16x16 32x32 48x48 64x64" type="image/png" href="/favicon.png">
    <link rel="stylesheet" href="/assets/css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body id="top">
	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-4 col-xs-4" id="logo">
					<a href="/"><img src="/assets/images/logo.png" class="logo img-responsive"></a>
				</div>
				<div class="col-md-3 col-sm-4 col-xs-4 phone" id="phone">
					<span class="title">{{trans('options.phone')}}</span>
					<span><a href="tel:+77279836731">+ 7 (727) 983 67 31</a></span>
					<span><a href="tel:+77076161414">+7 (707) 616 14 14</a></span>
				</div>
				<div class="col-md-3 address visible-md visible-lg">
					<span class="title">{{trans('options.address')}}</span>
					<span>{!!trans('options.header-address')!!}</span>
				</div>
				<div class="col-md-3 col-xs-4 col-sm-4 s-lang">
					<ul class="social">
						<li><a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
						<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
						<li><a href=""><i class="fa fa-vk" aria-hidden="true"></i></a></li>
					</ul>
					<div class="dropdown lang">
					  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					    {{trans('options.lang')}}
					    <span class="caret"></span>
					  </button>
					  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
					    <li><a href="/kk/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'kk') class="current" @endif>Қазақша</a></li>
						<li><a href="/ru/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'ru') class="current" @endif>Русский</a></li>
						<li><a href="/en/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'en') class="current" @endif>English</a></li>
					  </ul>
					</div>
				</div>
			</div>
		</div>
		<div class="menu">
			<nav class="navbar navbar-default">
				<div class="dropdown lang">
					  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					    {{trans('options.lang')}}
					    <span class="caret"></span>
					  </button>
					  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
					    <li><a href="/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'kk') class="current" @endif>Қазақша</a></li>
						<li><a href="/ru/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'ru') class="current" @endif>Русский</a></li>
						<li><a href="/en/{{$path}}" @if(\LaravelLocalization::getCurrentLocale() == 'en') class="current" @endif>English</a></li>
					  </ul>
					</div>
				<div class="navbar-header">
					 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-nav" aria-expanded="false">
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>
				</div>
				<div class="collapse navbar-collapse" id="main-nav">
					<div class="container">
						<ul class="nav navbar-nav">
							@foreach($menu[0] as $item)
										@if(isset($menu[$item->getMenuParentID()]))
											<li class="dropdown">
												<a class="dropdown-toggle" data-toggle="dropdown" href="#">{{$item->getTitle()}}<span class="caret"></span></a>
												<ul class="dropdown-menu">
													@foreach($menu[$item->getMenuParentID()] as $subItem)
														<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{$item->slug.'/'.$subItem->slug}}">{{$subItem->getTitle()}}</a></li>
													@endforeach
												</ul>
											</li>
										@elseif($item->slug != 'home')
											<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}{{$item->slug}}" class="">{{$item->getTitle()}}</a></li>
										@else
											<li><a href="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}">{{$item->getTitle()}}</a></li>
											@endif
							@endforeach	
					        				<li class="[ hidden-xs ] search-box">
					        					<a href="#" class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></a>
					        					<div class="search-div">
													<form method="get" action="/{{\LaravelLocalization::getCurrentLocale() == 'kk' ? '' : \LaravelLocalization::getCurrentLocale().'/'}}search">
														<div class="input-group">
															<input type="text" name="q" class="form-control">
														</div>
													</form>
					        					</div> 
					        				</li>

						</ul>
					</div>
				</div>
			</nav>
		</div>
	</header>

		@yield('content')
	
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-12 col-xs-12 contact">
					<div class="phone">
						<span class="title">{{trans('options.phone')}}</span>
						<span class="detail">
							<a href="tel:+77279836731">+ 7 (727) 983 67 31</a><br>
							<a href="tel:+77076161414">+7 (707) 616 14 14</a>
						</span>
					</div>
					<div class="email">
						<span class="title">E-mail</span>
						<span class="detail"><a href="mailto:meibukan.mac@gmail.com">meibukan.mac@gmail.com</a></span>
					</div>
				</div>
				<div class="col-md-9 col-xs-12 asdcz hidden-xs ">
					<div class="col-md-2 col-sm-4 col-xs-12 category">
						<span class="title center-block">{{trans('options.about-us')}}</span>
						<ul class="category-item">
							<li><a href="/about-us/about">{{trans('options.club')}}</a></li>
							<li><a href="/about-us/goals">{{trans('options.goal')}}</a></li>
							<li><a href="/about-us/frequently-asked-questions">{{trans('options.faq')}}</a></li>
							<li><a href="/about-us/contact">{{trans('options.contact')}}</a></li>
						</ul>
					</div>
					<div class="col-md-2 col-sm-4 col-xs-12 category">
						<span class="title center-block">{{trans('options.goju-ryu')}}</span>
						<ul class="category-item">
							<li><a href="/goju-ryu/history">{{trans('options.history')}}</a></li>
							<li><a href="/goju-ryu/feature">{{trans('options.feature')}}</a></li>
							<li><a href="/goju-ryu/rule">{{trans('options.rule')}}</a></li>
							<li><a href="/goju-ryu/terminology">{{trans('options.termin')}}</a></li>
						</ul>
					</div>
					<div class="col-md-2 col-sm-4 col-xs-12 category">
						<span class="title center-block">{{trans('options.program')}}</span>
						<ul class="category-item">
							<li><a href="/program/view/19">{{trans('options.children')}}</a></li>
							<li><a href="/program/view/17">{{trans('options.individual')}}</a></li>
							<li><a href="/program/view/11">{{trans('options.mini')}}</a></li>
							<li><a href="/program/view/80">{{trans('options.adults')}}</a></li>
							<li><a href="/program/view/82">{{trans('options.fitness')}}</a></li>
						</ul>
					</div>
					<div class="col-md-2 col-sm-6 col-xs-12 category">
						<span class="title center-block">{{trans('options.press')}}</span>
						<ul class="category-item">
							<li><a href="/press/news">{{trans('options.news')}}</a></li>
							<li><a href="/press/announcement">{{trans('options.announcement')}}</a></li>
							<li><a href="/press/mass-media">{{trans('options.mass-media')}}</a></li>
						</ul>
					</div>
					<div class="col-md-2 col-sm-6 col-xs-12 category last-block">
						<span class="title center-block">{{trans('options.media')}}</span>
						<ul class="category-item">
							<li><a href="/all-media/photo">{{trans('options.photo')}}</a></li>
							<li><a href="/all-media/video">{{trans('options.video')}}</a></li>
						</ul>
						<ul class="social visible-xs">
							<li><a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-vk" aria-hidden="true"></i></a></li>
						</ul>
					</div>
						<ul class="social visible-md visible-lg">
							<li><a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href=""><i class="fa fa-vk" aria-hidden="true"></i></a></li>
						</ul>
				</div>
			</div>
		</div>
		<div class="copyright">
			<div class="container text-center">
				Copyright © 2016 Meibukan Martial Arts Club 
			</div>
			
		</div>
	</footer>
	<script data-main="/assets/js/main.js" src="/assets/vendor/requirejs/require.js"></script>
</body>
</html>
