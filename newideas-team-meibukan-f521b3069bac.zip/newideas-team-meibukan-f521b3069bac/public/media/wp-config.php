<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
//define('DB_NAME', 'meibuk_db');
define('DB_NAME', 'meibuk_db');

/** MySQL database username */
//define('DB_USER', 'meibuk_usr');
define('DB_USER', 'meibuk_usr');
/** MySQL database password */
//define('DB_PASSWORD', '4rCeSMdwsY(t9G5RWT$$UXoD');
define('DB_PASSWORD', '4rCeSMdwsY(t9G5RWT$$UXoD');
/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

//define('WP_SITEURL', 'http://localhost:8000/media');
//define('WP_HOME', 'http://localhost:8000/media');
define('WP_SITEURL', 'http://meibukan.kz/media');
define('WP_HOME', 'http://meibukan.kz/media');
define('UPLOADS', 'uploads');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'tAjp_1(62Q/QAp9IJQ)/2;hL/]8_QxI1?$f10,!/p-%pC!/STKzHv>>jHX?BmJ]q');
define('SECURE_AUTH_KEY',  'RTb[kdW&O6Vx+Toz=:o<Snm~[.sh^(bwp3+pZL/xf14^jk>sl+jPazNN9E.[s5]-');
define('LOGGED_IN_KEY',    '}&1-%U6hydJ& a(A/=dg<f{#3,lVkf>F{ODjE8&H4[^NQ~lt~L_WSOmgZP<v3NhK');
define('NONCE_KEY',        '?;1b3&[4p_<]k{Kh?5m8.od87mH i(vy:H{&OB|:EvrD?)P#@`PAxDevhnQIed&+');
define('AUTH_SALT',        'no*a+eI7y>x@ZpF ZF?V|#jwRsn#91)[lKfKDr?;H8qHL,NM}V)$iga`#p<fIkG5');
define('SECURE_AUTH_SALT', ')Uh#9OsBi~-nH8/|8fs_:?.7U>emc[@9_,uKyjZD9+{OrUq:~{%qEH|-[V6hx/r-');
define('LOGGED_IN_SALT',   '$!Z;z<-8;< y9;&K >GeumL,`;#g6Fk<j7!!x3cWd(~C{xIo91;%3iKQ&2|I+%c[');
define('NONCE_SALT',       'fs3Cv- ?=8B<:sWpuFi+]4zVg!Nz[?yhbJV+&~#bs_YqmVkW7|hsESn~%y6ktG_@');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'mb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
