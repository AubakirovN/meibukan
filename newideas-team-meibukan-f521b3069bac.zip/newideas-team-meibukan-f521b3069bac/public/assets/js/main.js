'use strict';

require.config({
	paths: {
		"jquery": "../vendor/jquery/dist/jquery.min",
		"backbone": "../vendor/backbone-amd/backbone-min",
		"backbone.localstorage": "../vendor/backbone.localstorage/backbone.localStorage-min",
		"bootstrapjs": "../vendor/bootstrap/dist/js/bootstrap.min",
		"underscore": "../vendor/underscore-amd/underscore-min",
		"modernizr": "modernizr.min",
		"slick": "../vendor/slick-carousel/slick/slick.min",
		"masonry": "../vendor/masonry/dist/masonry.pkgd.min",
		"jquery-bridget": "../vendor/jquery-bridget/jquery-bridget",
		"maskedinput": "../vendor/jquery.maskedinput/dist/jquery.maskedinput.min",
		"googlemaps": "../vendor/googlemaps-amd/src/googlemaps",
		"async": "../vendor/requirejs-plugins/src/async",
		"easing": "../vendor/jquery.easing/js/jquery.easing.min",
		"lightbox": "../vendor/lightbox2/dist/js/lightbox.min",

	},
	shim: {
		"backbone": {
			deps: ['underscore', 'jquery', 'modernizr']
		},
		"bootstrapjs": {
			deps: ['jquery']
		},
		"masonry": {
			deps: ['jquery']
		},
		"maskedinput": {
			deps: ['jquery']
		},
		"easing":{
			deps: ['jquery']
		},
		"lightbox":{
			deps: ['jquery']
		}
	},
	googlemaps: {
		params: {
		  key: 'AIzaSyBDHBsSmYsQEQ1LRyzVORokJ9snp4rXdos',
		  libraries: 'geometry'
		}
  	}
});

require(['views/app'], function(AppView) {
	new AppView;
});