define(['backbone', 'bootstrapjs', 'slick', 'masonry', 'jquery-bridget', 'maskedinput', 'easing', 'googlemaps!','lightbox'], function(Backbone) {

	var App = Backbone.View.extend({

		el:'body',

		events:{
			'click #lesson button.send':'enrollToLesson',
			'click .contact-form button.contact':'contactUs',
			'click button.enroll':'enrollToLesson2',
			'click .search-box .search-btn':'search'
		},

		initialize:function(){
			var self = this;

			$(window).resize(function(){
			   //console.log('resize called');
			   var width = $(window).width();
			   if(width <= 480){
			       $('#logo').removeClass('col-xs-4').addClass('col-xs-6');
			       $('#phone').removeClass('col-xs-4').addClass('col-xs-6');
			   }
			   else if(width >= 481 && width <= 768){
			   	   $('#logo').removeClass('col-xs-6').addClass('col-xs-4');
			       $('#phone').removeClass('col-xs-6').addClass('col-xs-4');
			   }
			})
			.resize();//trigger the resize event on page load.

			$(".phone-input").mask("+7 (999) 999 9999");
			$(".tel-input").mask("+7 (999) 999 9999");


			$('a.page-scroll').bind('click', function(e){
				e.preventDefault();

				var $anchor = $(this);

				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top
				}, 1500, 'easeInOutExpo');
				
			});

			$('nav').affix({
				offset: {
			    	top: function() {
             			return this.top = $('nav').offset().top
           			}
			  	}
			});

			$('.collapse').on('shown.bs.collapse', function(){
			$(this).parent().find(".fa-caret-right").removeClass("fa-caret-right").addClass("fa-caret-down");
			}).on('hidden.bs.collapse', function(){
			$(this).parent().find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-right");
			});

			$('.main-slider').slick({
				autoplay: true,
				dots: true,
				lazyLoad: 'ondemand',
				speed: 200,
				responsive: [
					{
				      breakpoint: 768,
				      settings: {
				        dots: false,
				        arrows: false
				      }
				    }
				]
			});	

			$('.feedbacks').slick({
				  dots: true,
				  arrows:false,
				  
				  infinite: false,
				  speed: 300,
				  slidesToShow: 3,
				  slidesToScroll: 3,
				  responsive: [
				    {
				      breakpoint: 1024,
				      settings: {
				        slidesToShow: 2,
				        slidesToScroll: 2,
				        infinite: true,
				        dots: true
				      }
				    },
				    {
				      breakpoint: 600,
				      settings: {
				        slidesToShow: 2,
				        slidesToScroll: 2,
				        arrows: false
				      }
				    },
				    {
				      breakpoint: 480,
				      settings: {
				        slidesToShow: 1,
				        slidesToScroll: 1,
				        arrows: false
				      }
				    }
				  ]
			});

			// Google maps
			// Basic options for a simple Google Map
		    // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
		    var mapOptions = {
		        // How zoomed in you want the map to start at (always required)
		        zoom: 12,

		        // The latitude and longitude to center the map (always required)
		        center: new google.maps.LatLng(43.226707, 76.862482),

		        // Disables the default Google Maps UI components
		        scrollwheel: false,
		        draggable: true,

		        // How you would like to style the map. 
		        // This is where you would paste any style found on Snazzy Maps.
		        
		    };
		    //Locations info
		    var json = [
	            {
	                "title": "Meibukan 1",
	                "lat": 43.20131246,
	                "lng": 76.83724165,
	                "description": "ЯССАУИ КӨШ. 1Б, СК 'МЕДИНА'"
	            },
	            {
	                "title": "Meibukan 2",
	                "lat": 43.21735866,
	                "lng": 76.94054961,
	                "description": "ШУКШИН КӨШ. 71, 'HARDFITNESS' ФИТНЕС-КЛУБЫ"
	            },
	            {
	                "title": "Meibukan 3",
	                "lat": 43.230815,
	                "lng": 76.893278,
	                "description": "РАДОСТОВЕЦ КӨШ. 152Д/1, 'RONIN' КЛУБЫ"
	            }
	        ]

		    // Get the HTML DOM element that will contain your map 
		    var mapElement = document.getElementById('map');

			// Create the Google Map using out element and options defined above
    		var map = new google.maps.Map(mapElement, mapOptions);

    		var myLatLng = new google.maps.LatLng(43.20131246, 76.83724165);
    		

		    var infowindow = new google.maps.InfoWindow({
			  content:""
			  });

		    for (var i = 0, length = json.length; i < length; i++) {
			        var data=json[i];
			        var latLng = new google.maps.LatLng(data.lat, data.lng); 
			        // Creating a marker and putting it on the map
			        var marker = new google.maps.Marker({
			            position: latLng,
			            map: map,
			            title: data.title
			        });

			        bindInfoWindow(marker, map, infowindow, data.description);
			    } 
			

			function bindInfoWindow(marker, map, infowindow, description) {
			    marker.addListener('click', function() {
			        infowindow.setContent(description);
			        infowindow.open(map, this);
			    });
			}

		    var $window = $(window),
		    	win_height_padded = $window.height() * 1.1,
		      	isTouch = Modernizr.touch;

		    if (isTouch) { $('.revealOnScroll').addClass('animated'); }

			$window.on('scroll', revealOnScroll);

			function revealOnScroll() {
			    var scrolled = $window.scrollTop(),
			        win_height_padded = $window.height() * 1.1;

			    // Showed...
			    $(".revealOnScroll:not(.animated)").each(function () {
			      var $this     = $(this),
			          offsetTop = $this.offset().top;

			      if (scrolled + win_height_padded > offsetTop) {
			        if ($this.data('timeout')) {
			          window.setTimeout(function(){
			            $this.addClass('animated ' + $this.data('animation'));
			          }, parseInt($this.data('timeout'),10));
			        } else {
			          $this.addClass('animated ' + $this.data('animation'));
			        }
			      }
			    });
		}

			revealOnScroll();
		},

		search: function(e) {
			e.preventDefault();

			$(".search-btn").toggleClass("expanded");
			$(".search-div").toggleClass("show");
			$(".search-div input").focus();
		},

		enrollToLesson: function(e) {
			e.preventDefault();

			var form = $(e.target).closest('#lesson');

			var name = form.find('.name-input');
			var phone = form.find('.phone-input');

			if(name.val() === '')
			{
				name.focus();
				name.css('border', '1px solid red');
				return false;
			}
			else {
				name.css('border', '1px solid black');
				
			}
			if(phone.val() === '' || phone.val().length < 7)
			{
				phone.focus();
				phone.css('border', '1px solid red');
				return false;
			}
			else {
				phone.css('border', '1px solid black');
				
			}

			$.ajaxSetup({
			        headers: {
			            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			        }
			});
			
			$.ajax({
				type:"POST",
				url: "/ajax/mail",
				data: 'name='+name.val()+'&phone='+phone.val(),
				cache: false,
				success: function(){
					name.val('');
					phone.val('');
					form.find('.text-center').replaceWith('<p class="text-center success" style="color:#69bd45;">Спасибо, Ваш вопрос принят!</p>');
				}
			});
		},

		enrollToLesson2: function(e) {
			e.preventDefault();

			var form = $(e.target).closest('#form-for-record');

			var phone = form.find('.tel-input');

			if(phone.val() === '' || phone.val().length < 7)
			{
				phone.focus();
				phone.css('border', '1px solid red');
				return false;
			}
			else {
				phone.css('border', '1px solid black');
			}
		

			$.ajaxSetup({
			        headers: {
			            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			        }
			});

			$.ajax({
				type:"POST",
				url: "/ajax/mail",
				data: '&phone='+phone.val(),
				cache: false,
				success: function(){
					phone.val('');
				}
			});
		},

		contactUs: function(e) {
			e.preventDefault();

			var form = $('.contact-form');
			var name = form.find('.name-input');
			var email = form.find('.email-input');
			var msg = form.find('.msg-input');

		
			if(name.val() === '')
			{
				name.focus();
				name.css('border', '1px solid red');
				return false;
			}
			else {
				name.css('border', '1px solid #ccc');
				
			}
			if(email.val() === '')
			{	
				email.focus();
				email.css('border', '1px solid red');
				return false;
			}
			else {
				email.css('border', '1px solid #ccc');
				
			}

			$.ajaxSetup({
			        headers: {
			            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			        }
			});
			
			$.ajax({
				type:"POST",
				url: "/ajax/mail",
				data: 'name='+name.val()+'&email='+email.val()+'&msg='+msg.val(),
				cache: false,
				success: function(){
					name.val('');
					email.val('');
					msg.val('');
					form.find('.text-center').replaceWith('<p class="text-center success" style="color:#69bd45;">Спасибо, Ваш вопрос принят!</p>');
				}
			});
		}

	});
	return App;
});
