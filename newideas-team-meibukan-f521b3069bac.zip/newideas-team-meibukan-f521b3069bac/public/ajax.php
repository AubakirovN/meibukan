<?php

require_once('phpmailer/class.phpmailer.php');

if(isset($_POST['name']) && isset($_POST['phone']))
{
	$text = 'Имя: '.htmlspecialchars($_POST['name']).'<br>Email: '.htmlspecialchars($_POST['email']).'<br>Телефон: '.htmlspecialchars($_POST['phone']);

	$mail = new PHPMailer();
	$mail->SMTPAuth = true;
	$mail->Host = "mail.omer.kz";
	$mail->Port = 25;
	$mail->Username = "no-reply@omer.kz";
	$mail->Password = "5hoUs?01";

	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->From = 'no-reply@omer.kz';
	$mail->FromName = 'Omer.kz';
	
	$mail->Subject = "Заявка";
	$mail->Body = $text;
	$mail->AddAddress("lifebek@mail.ru");

	if(!$mail->Send()) {
	  echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
	  echo "Message sent!";
	}
}
else
{
	echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL '. $_SERVER['REQUEST_URI'] .' was not found on this server.</p><p>Additionally, a 404 Not Founderror was encountered while trying to use an ErrorDocument to handle the request.</p></body></html>';
	header("HTTP/1.1 404 Not Found");
}

?>